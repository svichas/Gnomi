"""Run after moving/extracting this folder to create a relinked Synthcut project."""
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
project=json.loads((root/'Gnomi.aive').read_text())
for asset in project['assets']:
    name=Path(asset['path']).name
    target=root/name if asset.get('hasVideo') else root/'assets'/name
    if not target.exists(): raise FileNotFoundError(target)
    asset['path']=str(target)
(root/'Gnomi-relocated.aive').write_text(json.dumps(project,indent=2))
print(root/'Gnomi-relocated.aive')
