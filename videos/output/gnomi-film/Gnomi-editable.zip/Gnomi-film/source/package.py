"""Mux optional subtitles and bundle the editable project after a Synthcut export."""
from pathlib import Path
import subprocess, zipfile, json
root=Path(__file__).resolve().parents[1]
subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(root/'Gnomi-master.mp4'),'-i',str(root/'Gnomi.en.srt'),'-map','0:v','-map','0:a','-map','1:0','-map_chapters','-1','-c:v','copy','-c:a','copy','-c:s','mov_text','-metadata','title=Gnomi — Perspective before you ship','-metadata:s:s:0','language=eng','-metadata:s:s:0','title=English','-disposition:s:0','0','-movflags','+faststart',str(root/'Gnomi-explainer.mp4')],check=True)
subprocess.run(['ffmpeg','-v','error','-i',str(root/'Gnomi-explainer.mp4'),'-f','null','-'],check=True)
subprocess.run(['ffmpeg','-y','-loglevel','error','-ss','8.5','-i',str(root/'Gnomi-explainer.mp4'),'-frames:v','1',str(root/'cover.jpg')],check=True)
subprocess.run(['ffmpeg','-y','-loglevel','error','-ss','94.5','-i',str(root/'Gnomi-explainer.mp4'),'-frames:v','1',str(root/'frames/final-hypotheses.png')],check=True)
subprocess.run(['ffmpeg','-y','-loglevel','error','-f','concat','-safe','0','-i',str(root/'source/storyboard.txt'),'-vf','scale=480:270,tile=2x7:padding=12:margin=12:color=0xF6F5F0','-frames:v','1',str(root/'storyboard.jpg')],check=True)
with zipfile.ZipFile(root/'Gnomi-editable.zip','w',zipfile.ZIP_DEFLATED,compresslevel=5) as z:
    for f in root.rglob('*'):
        if not f.is_file() or any(x in {'node_modules','frames'} for x in f.relative_to(root).parts):continue
        if f.suffix=='.zip' or f.name.startswith('visual-') or f.name in {'Gnomi-master.mp4','qa.log','chapters.ffmetadata','visuals.mp4','revise-inputs.py','concat.txt','input-options-transcript.json','narration-revised.wav','input-options-pickup.mp3','narration-1.mp3','narration-2.mp3','narration-3.mp3','narration-4.mp3'}:continue
        z.write(f,Path('Gnomi-film')/f.relative_to(root))
with zipfile.ZipFile(root/'Gnomi-editable.zip') as z:assert z.testzip() is None
project=json.loads((root/'Gnomi.aive').read_text())
assert all(Path(a['path']).exists() for a in project['assets'])
print('Verified final MP4, source archive, and all project media references.')
