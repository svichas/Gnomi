"""Rebuild revision 4's narration edit and extended music from preserved source takes."""
from pathlib import Path
import subprocess
root = Path(__file__).resolve().parents[1]
subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', str(root/'assets/narration-v4.mp3'),
 '-filter_complex', '[0:a]asplit=2[a][b];[a]atrim=end=27.3,afade=t=out:st=27.285:d=0.015,asetpts=PTS-STARTPTS[pre];[b]atrim=start=29.5,asetpts=PTS-STARTPTS,afade=t=in:d=0.015[post];[pre][post]concat=n=2:v=0:a=1[out]',
 '-map', '[out]', '-ar', '48000', '-c:a', 'pcm_s16le', str(root/'assets/narration-v4-edited.wav')], check=True)
subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', str(root/'assets/music.mp3'),
 '-filter_complex', '[0:a]asplit=2[a][b];[a][b]acrossfade=d=5:c1=tri:c2=tri,atrim=duration=108[out]',
 '-map', '[out]', '-ar', '48000', '-c:a', 'pcm_s16le', str(root/'assets/music-v4.wav')], check=True)
