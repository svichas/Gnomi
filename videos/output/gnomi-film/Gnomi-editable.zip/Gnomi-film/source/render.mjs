import {chromium} from '../../../node_modules/playwright-core/index.mjs';
import {createServer} from 'node:http';import {readFileSync,writeFileSync,existsSync,mkdirSync} from 'node:fs';import {resolve,extname} from 'node:path';import {spawn} from 'node:child_process';import {once} from 'node:events';
const root=resolve('output/gnomi-film');const mime={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.woff2':'font/woff2','.png':'image/png','.svg':'image/svg+xml','.json':'application/json'};
const server=createServer((req,res)=>{try{const p=resolve(root,'.'+decodeURIComponent(req.url.split('?')[0]));if(!p.startsWith(root+'/'))throw 0;res.setHeader('Content-Type',mime[extname(p)]||'application/octet-stream');res.end(readFileSync(p));}catch{res.statusCode=404;res.end('Missing');}});await new Promise(r=>server.listen(8177,'127.0.0.1',r));
const browser=await chromium.launch({headless:true,args:['--use-angle=metal','--disable-web-security','--disable-background-timer-throttling','--disable-renderer-backgrounding']});
const makePage=async()=>{const p=await browser.newPage({viewport:{width:1920,height:1080},deviceScaleFactor:1});p.on('pageerror',e=>console.error(e));await p.goto('http://127.0.0.1:8177/source/index.html');await p.waitForFunction(()=>window.ready);return p;};
const mode=process.argv[2]||'stills';
if(mode==='stills'){
 const page=await makePage();for(const s of [2.5,8.5,16.5,25.5,34.5,44.5,57.5,67.5,74.5,82.5]){await page.evaluate(f=>window.setFrame(f),Math.round(s*24));await page.screenshot({path:`${root}/frames/scene-${s}.png`});console.log('Frame',s);}
 const bytes=await page.evaluate(()=>window.exportModels());writeFileSync(`${root}/assets/gnomi-personas.glb`,Buffer.from(bytes));
}else{
 const N=2088,workers=3;await Promise.all(Array.from({length:workers},(_,i)=>i).filter(i=>!process.argv[3]||i===Number(process.argv[3])).map(async(i)=>{const page=await makePage();const start=Math.floor(N*i/workers),end=Math.floor(N*(i+1)/workers);const ff=spawn('ffmpeg',['-y','-loglevel','error','-f','image2pipe','-framerate','24','-vcodec','mjpeg','-i','pipe:0','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',`${root}/visual-${i}.mp4`]);ff.stderr.on('data',x=>console.error(x.toString()));
 for(let f=start;f<end;f++){await page.evaluate(f=>window.setFrame(f),f);const b=await page.screenshot({type:'jpeg',quality:96});if(!ff.stdin.write(b))await once(ff.stdin,'drain');if((f-start)%120===0)console.log(`worker ${i}: ${f-start}/${end-start}`);}
 ff.stdin.end();await once(ff,'close');await page.close();console.log(`worker ${i} complete`);
 }));}
await browser.close();server.close();
