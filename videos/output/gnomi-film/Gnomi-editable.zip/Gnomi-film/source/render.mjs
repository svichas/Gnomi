import {chromium} from 'playwright-core';
import {createServer} from 'node:http';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve,extname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
const root=fileURLToPath(new URL('../',import.meta.url));
const production=JSON.parse(readFileSync(resolve(root,'source/production.json')));
const mime={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.woff2':'font/woff2','.png':'image/png','.svg':'image/svg+xml','.json':'application/json'};
const server=createServer((req,res)=>{try{const p=resolve(root,'.'+decodeURIComponent(req.url.split('?')[0]));if(!p.startsWith(root))throw 0;res.setHeader('Content-Type',mime[extname(p)]||'application/octet-stream');res.end(readFileSync(p));}catch{res.statusCode=404;res.end('Missing');}});
await new Promise(r=>server.listen(8177,'127.0.0.1',r));
let browser;
try {
 browser=await chromium.launch({headless:true,args:['--use-angle=metal','--disable-web-security','--disable-background-timer-throttling','--disable-renderer-backgrounding']});
 const makePage=async()=>{const p=await browser.newPage({viewport:{width:1920,height:1080},deviceScaleFactor:1});p.on('pageerror',e=>{throw e;});await p.goto('http://127.0.0.1:8177/source/index.html');await p.waitForFunction(()=>window.ready);return p;};
 const mode=process.argv[2]||'stills';
 if(mode==='stills'){
  mkdirSync(resolve(root,'frames'),{recursive:true});
  const page=await makePage();
  const times=production.scenes.flatMap(s=>s.beats?s.beats.map(b=>s.start+b.at+1.5):[(s.start+s.end)/2]);
  for(let i=0;i<times.length;i++){await page.evaluate(f=>window.setFrame(f),Math.round(times[i]*24));await page.screenshot({path:resolve(root,`frames/revision-4-${i}.png`)});console.log('Frame',i,times[i].toFixed(2));}
  writeFileSync(resolve(root,'source/storyboard.txt'),times.map((_,i)=>`file '../frames/revision-4-${i}.png'`).join('\n')+'\n');
 }else{
  const N=production.duration*production.fps,workers=1;
  await Promise.all(Array.from({length:workers},(_,i)=>i).filter(i=>!process.argv[3]||i===Number(process.argv[3])).map(async(i)=>{
   const page=await makePage();const start=Math.floor(N*i/workers),end=Math.floor(N*(i+1)/workers);
   const ff=spawn('ffmpeg',['-y','-loglevel','error','-f','image2pipe','-framerate',String(production.fps),'-vcodec','mjpeg','-i','pipe:0','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',resolve(root,`visual-v4-${i}.mp4`)]);
   ff.stderr.on('data',x=>process.stderr.write(x));
   for(let f=start;f<end;f++){await page.evaluate(f=>window.setFrame(f),f);const b=await page.screenshot({type:'jpeg',quality:96,timeout:120000});if(!ff.stdin.write(b))await once(ff.stdin,'drain');if((f-start)%120===0)console.log(`worker ${i}: ${f-start}/${end-start}`);}
   ff.stdin.end();const [code]=await once(ff,'close');if(code!==0)throw new Error(`Encoder exited ${code}`);await page.close();console.log(`worker ${i} complete`);
  }));
  writeFileSync(resolve(root,'source/concat-v4.txt'),Array.from({length:workers},(_,i)=>`file '../visual-v4-${i}.mp4'`).join('\n')+'\n');
 }
} finally {await browser?.close();server.close();}
