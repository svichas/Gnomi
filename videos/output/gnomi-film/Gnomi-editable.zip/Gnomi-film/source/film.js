import * as THREE from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
import {GLTFExporter} from 'three/addons/exporters/GLTFExporter.js';
const W=1270,H=900, duration=87, fps=24;
const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,preserveDrawingBuffer:true});renderer.setSize(W,H);renderer.setPixelRatio(1);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.VSMShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.06;document.querySelector('#three').appendChild(renderer.domElement);
const scene=new THREE.Scene();const pmrem=new THREE.PMREMGenerator(renderer);scene.environment=pmrem.fromScene(new RoomEnvironment(),.04).texture;scene.environmentIntensity=.32;
const camera=new THREE.PerspectiveCamera(36,W/H,.1,100);camera.position.set(0,5,13.6);camera.lookAt(0,1,0);
const ambient=new THREE.HemisphereLight(0xffffff,0xc2bdac,1.7);scene.add(ambient);const sun=new THREE.DirectionalLight(0xfff5e7,3.0);sun.position.set(-5,9,5);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);sun.shadow.camera.left=-8;sun.shadow.camera.right=8;sun.shadow.camera.top=8;sun.shadow.camera.bottom=-8;sun.shadow.normalBias=.04;sun.shadow.bias=-.0002;sun.shadow.radius=18;sun.shadow.blurSamples=20;scene.add(sun);
const fill=new THREE.DirectionalLight(0xd4dfcb,1.1);fill.position.set(6,3,-3);scene.add(fill);
const floor=new THREE.Mesh(new THREE.PlaneGeometry(200,200),new THREE.ShadowMaterial({opacity:.08}));floor.rotation.x=-Math.PI/2;floor.position.y=-.12;floor.receiveShadow=true;scene.add(floor);
const C={olive:'#58684E',sage:'#AAB69E',cream:'#E5E1D6',ink:'#2C332D',clay:'#B59B87',blue:'#879C97',gold:'#BDB394',lilac:'#A5A599'};
const mat=(color,metalness=0,roughness=.78)=>new THREE.MeshStandardMaterial({color,metalness,roughness});
const mats=Object.fromEntries(Object.entries(C).map(([k,c])=>[k,mat(c)]));const white=mat('#FEFDF9');
function mesh(geo,material,parent,x=0,y=0,z=0){const o=new THREE.Mesh(geo,material);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o;}
function box(parent,w,h,d,x,y,z,m=white,r=.1){return mesh(new RoundedBoxGeometry(w,h,d,6,r),m,parent,x,y,z)}
function sphere(parent,r,x,y,z,m){return mesh(new THREE.SphereGeometry(r,32,24),m,parent,x,y,z)}
function label(text,w=3,h=.7,bg='#F6F5F0',color='#222823',size=48){const canvas=document.createElement('canvas');canvas.width=1024;canvas.height=Math.round(1024*h/w);const ctx=canvas.getContext('2d');if(bg){ctx.fillStyle=bg;ctx.fillRect(0,0,canvas.width,canvas.height);}ctx.fillStyle=color;ctx.font=`500 ${size}px Inter`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(text,512,canvas.height/2);const tex=new THREE.CanvasTexture(canvas);tex.colorSpace=THREE.SRGBColorSpace;const ob=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:tex,side:THREE.DoubleSide,toneMapped:false,transparent:!bg,depthWrite:!!bg}));return ob;}
// A two-form ceramic figure: one continuous body and a softly separated head.
// Variation is expressed through silhouette and material, without tiny accessories.
const profile=new THREE.SplineCurve([
 new THREE.Vector2(0,.025),new THREE.Vector2(.25,.025),new THREE.Vector2(.34,.065),
 new THREE.Vector2(.365,.15),new THREE.Vector2(.35,.32),new THREE.Vector2(.315,.62),
 new THREE.Vector2(.28,.85),new THREE.Vector2(.23,1.00),new THREE.Vector2(.14,1.075),new THREE.Vector2(0,1.09)
]).getPoints(72).map(p=>new THREE.Vector2(Math.max(0,p.x),p.y));
const bodyGeometry=new THREE.LatheGeometry(profile,64);
const headGeometry=new THREE.SphereGeometry(.255,48,32);
const shadowCanvas=document.createElement('canvas');shadowCanvas.width=shadowCanvas.height=128;
const shadowContext=shadowCanvas.getContext('2d');const gradient=shadowContext.createRadialGradient(64,64,4,64,64,62);
gradient.addColorStop(0,'rgba(34,40,35,0.16)');gradient.addColorStop(.45,'rgba(34,40,35,0.07)');gradient.addColorStop(1,'rgba(34,40,35,0)');
shadowContext.fillStyle=gradient;shadowContext.fillRect(0,0,128,128);
const contactMaterial=new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(shadowCanvas),transparent:true,depthWrite:false,toneMapped:false});
function person(color='olive',variant=0){
 const g=new THREE.Group();g.name=`Gnomi ceramic persona ${color} ${variant}`;
 const height=[1,.94,1.07,.98,1.04][variant%5],width=[1,1.08,.94,1.04,.97][variant%5];
 const body=mesh(bodyGeometry,mats[color],g);body.scale.set(width,height,.88*width);
 const head=mesh(headGeometry,mats[color],g,0,1.43*height,0);head.scale.set(1,height,1);
 const contact=new THREE.Mesh(new THREE.PlaneGeometry(1.2,1.0),contactMaterial);contact.rotation.x=-Math.PI/2;contact.position.y=.006;contact.name='Contact shadow';g.add(contact);
 return g;
}
function plinth(g,r=3.2){return mesh(new THREE.CylinderGeometry(r,r,.07,96),mat('#EEEDE6'),g,0,-.07,0)}
const texLoader=new THREE.TextureLoader();const textures={};await document.fonts.ready;for(const f of ['setup-ui','audience-ui','swarm-ui','timeline-ui']){try{textures[f]=await texLoader.loadAsync('../assets/'+f+'.png');textures[f].colorSpace=THREE.SRGBColorSpace;}catch{}}
function screen(key,w=5.7,h=3.8){
 const g=new THREE.Group();g.name='Thin floating product display';
 box(g,w+.17,h+.17,.12,0,2.45,0,mats.ink,.10);
 box(g,w+.12,h+.12,.10,0,2.45,-.075,mats.cream,.09);
 mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:textures[key],toneMapped:false}),g,0,2.45,.066);
 g.traverse(o=>{o.castShadow=false;});
 return g;
}
function line(parent,pts,color=C.sage,r=.018){const curve=new THREE.CatmullRomCurve3(pts.map(p=>new THREE.Vector3(...p)));const ob=mesh(new THREE.TubeGeometry(curve,40,r,8,false),mat(color,0,.72),parent);ob.userData.curve=curve;return ob;}
function group(){const g=new THREE.Group();scene.add(g);g.visible=false;return g;}
const groups=[],anim=[];
// 01 — Product familiarity meets a new perspective.
{
 const g=group();groups.push(g);plinth(g,3.3);const monitor=screen('setup-ui',4.5,3.13);monitor.position.set(.35,0,-.6);monitor.rotation.y=-.12;g.add(monitor);
 const p=person('olive',1);p.position.set(-2.15,0,1.8);p.scale.setScalar(1.1);p.rotation.y=.5;g.add(p);
 const q=label('?',.65,.8,null,C.olive,720);q.position.set(-2.0,2.4,1.8);g.add(q);
 anim.push((u,t)=>{g.rotation.y=-.10+u*.15;p.position.y=Math.sin(t*2)*.025;q.position.y=2.5+Math.sin(t*2)*.1;});
}
// 02 — A little universe of different perspectives.
{
 const g=group();groups.push(g);plinth(g,2.8);const ring=mesh(new THREE.TorusGeometry(1.8,.085,24,128),mats.olive,g,0,2.1,0);ring.rotation.x=.13;
 const chip=box(g,1.45,1.45,.28,0,2.1,.12,mats.olive,.20);const icon=await texLoader.loadAsync('../assets/gnomi-icon-reversed.svg');icon.colorSpace=THREE.SRGBColorSpace;mesh(new THREE.PlaneGeometry(.91,.91),new THREE.MeshBasicMaterial({map:icon,transparent:true,toneMapped:false}),g,0,2.1,.28);
 const people=[];for(let i=0;i<5;i++){const p=person(['olive','blue','clay','gold','lilac'][i],i);g.add(p);people.push(p);}
 anim.push((u,t)=>{ring.rotation.y=Math.sin(t*.4)*.18;people.forEach((p,i)=>{const a=i*Math.PI*2/5+u*.3;p.position.set(Math.cos(a)*2.5,0,Math.sin(a)*1.8);p.rotation.y=-a*.2;p.scale.setScalar(.7);});});
}
// 03 — Audience as many individuals, not one average.
{
 const g=group();groups.push(g);const people=[];
 for(let i=0;i<9;i++){const p=person(['olive','blue','clay','gold','lilac'][i%5],i);p.position.set((i%3-1)*1.9,0,(Math.floor(i/3)-1)*1.8);g.add(p);people.push(p);}
 anim.push((u,t)=>{g.rotation.y=-.23+u*.18;people.forEach((p,i)=>{const a=Math.max(0,Math.min(1,(u*7-i*.25)));p.scale.setScalar(.15+.85*(1-Math.pow(1-a,3)));p.position.y=Math.sin(t*1.6+i)*.035;});});
}
// 04 — Three starting points, expressed as simple sculptural cards.
{
 const g=group();groups.push(g);plinth(g,3.8);const cards=[];
 ['Idea','Staging app','Figma design'].forEach((name,i)=>{
  const card=new THREE.Group();card.name=name+' input';
  box(card,2.05,2.85,.14,0,0,0,white,.13);
  const heading=label(name,1.90,.42,null,C.ink,76);heading.position.set(0,.97,.082);card.add(heading);
  if(i===0){
   sphere(card,.32,0,.23,.16,mats.gold);box(card,.22,.24,.13,0,-.16,.16,mats.olive,.04);
   box(card,1.13,.035,.025,0,-.63,.09,mats.sage,.012);box(card,.82,.035,.025,-.15,-.80,.09,mats.sage,.012);
  }else if(i===1){
   box(card,1.77,1.26,.055,0,.01,.10,mats.ink,.06);
   mesh(new THREE.PlaneGeometry(1.65,1.15),new THREE.MeshBasicMaterial({map:textures['setup-ui'],toneMapped:false}),card,0,.01,.13);
   box(card,.76,.035,.025,0,-.80,.09,mats.sage,.012);
  }else{
   box(card,1.60,1.48,.045,0,-.05,.11,mats.cream,.06);
   box(card,1.29,.09,.025,0,.46,.15,mats.sage,.025);
   box(card,.54,.57,.03,-.36,-.03,.15,mats.blue,.04);box(card,.54,.57,.03,.36,-.03,.15,mats.sage,.04);
   box(card,.79,.15,.03,0,-.53,.15,mats.olive,.04);
  }
  card.traverse(o=>{o.castShadow=false;});g.add(card);cards.push(card);
 });
 const p=person('blue',2);p.position.set(0,0,1.8);p.scale.setScalar(.68);g.add(p);
 anim.push((u,t)=>{g.rotation.y=-.07+u*.13;cards.forEach((c,i)=>{
  const e=1-Math.pow(1-Math.min(1,Math.max(0,u*6-i*.13)),3);
  c.position.set((i-1)*2.35,2.75+Math.sin(t*.7+i)*.035+(1-e)*.35,-.45+Math.abs(i-1)*.1);
  c.rotation.y=(i-1)*-.12;c.scale.setScalar(.88+e*.12);
 });});
}
// 05 — A step becomes evidence.
{
 const g=group();groups.push(g);plinth(g,3.2);const monitor=screen('timeline-ui',5.9,4.1);monitor.position.set(0,0,-.6);monitor.rotation.y=-.13;g.add(monitor);
 const p=person('clay',1);p.position.set(2.5,0,1.8);p.scale.setScalar(.95);g.add(p);
 const target=mesh(new THREE.TorusGeometry(.33,.045,12,64),mats.clay,g,-1.2,2.8,1.1);
 anim.push((u,t)=>{g.rotation.y=-.04+u*.1;target.scale.setScalar(.85+Math.sin(t*5)*.12);target.position.y=2.7-Math.min(u*2,1)*.3;});
}
// 06 — Opinion passes through a population in three-dimensional space.
{
 const g=group();groups.push(g);const people=[],paths=[],beads=[];plinth(g,3.8);
 const positions=Array.from({length:8},(_,i)=>{const a=i*Math.PI*2/8;return [Math.cos(a)*3,0,Math.sin(a)*2.5];});
 positions.forEach((pos,i)=>{const p=person(['clay','olive','olive','blue','lilac','gold','blue','olive'][i],i);p.position.set(...pos);p.scale.setScalar(.75);p.rotation.y=-pos[0]*.07;g.add(p);people.push(p);});
 for(let i=1;i<8;i++){const a=positions[0],b=positions[i];const path=line(g,[[a[0],.55,a[2]],[(a[0]+b[0])/2,1.1+Math.sin(i)*.2,(a[2]+b[2])/2],[b[0],.55,b[2]]],i%3===0?C.blue:C.olive,.022);paths.push(path);beads.push(sphere(g,.10,0,0,0,mats.clay));}
 const bubble=label('“Where is the next step?”',3.2,.6,null,C.ink,44);bubble.position.set(0,2.9,0);g.add(bubble);
 anim.push((u,t)=>{g.rotation.y=-.35+u*.65;paths.forEach((p,i)=>{const k=(u*2.2-i*.1);p.visible=k>0;beads[i].visible=k>0;beads[i].position.copy(p.userData.curve.getPoint(Math.max(0,Math.min(1,k%1))));});bubble.rotation.y=-g.rotation.y;people.forEach((p,i)=>p.position.y=Math.sin(t*1.4+i)*.03);});
}
// 07 — A report assembles from facts, with the pitch's documented example.
{
 const g=group();groups.push(g);const cards=[];
 const specs=[['01 / POTENTIAL FRICTION','Exact username required','No suggestions in the field',C.olive],['02 / EVIDENCE','A validation error','Step + screenshot + quote',C.blue],['03 / SUGGESTED CHANGE','Add a user picker','Validate with real people',C.clay]];
 specs.forEach((s,i)=>{const card=new THREE.Group();box(card,4.5,2.15,.13,0,0,0,white,.12);
 const l1=label(s[0],4.1,.40,null,s[3],34);l1.position.set(0,.7,.075);card.add(l1);
 const l2=label(s[1],4.1,.65,null,C.ink,57);l2.position.set(0,.05,.076);card.add(l2);
 const l3=label(s[2],4.1,.45,null,'#686D65',35);l3.position.set(0,-.6,.077);card.add(l3);card.traverse(o=>{o.castShadow=false;});g.add(card);cards.push(card);});
 anim.push((u,t)=>{cards.forEach((c,i)=>{const e=Math.min(1,Math.max(0,u*4-i*.45));c.scale.setScalar(.85);c.position.set((i-1)*.28+(1-e)*4,4.4-i*1.85,i*.35);c.rotation.y=-.12+Math.sin(t*.5+i)*.035;c.rotation.z=(i-1)*-.025;});});
}
// 08 — Local machine and a deliberately visible provider connection.
{
 const g=group();groups.push(g);const laptop=new THREE.Group();box(laptop,3.1,.18,2.1,0,.2,0,mats.ink,.15);const display=box(laptop,3,2,.15,0,1.28,-.85,mats.ink,.15);display.rotation.x=-.15;
 const l=label('Your machine',2.6,.6,null,'#E5E1D6',68);l.position.set(0,1.4,-.73);l.rotation.x=-.15;laptop.add(l);g.add(laptop);laptop.position.set(-1.8,0,1);laptop.rotation.y=.2;
 const cloud=new THREE.Group();box(cloud,2.4,1.5,.5,0,2.1,0,mats.sage,.3);const l2=label('Model provider',2.05,.65,null,C.ink,76);l2.position.set(0,2.1,.26);cloud.add(l2);cloud.position.set(2,0,-.9);g.add(cloud);
 const path=line(g,[[-.4,.9,.5],[.7,1.6,.2],[1.9,1.7,-.5]],C.olive,.035);const bead=sphere(g,.11,0,0,0,mats.gold);
 anim.push((u,t)=>{g.rotation.y=-.1+u*.12;cloud.position.y=Math.sin(t)*.06;bead.position.copy(path.userData.curve.getPoint((u*3)%1));});
}
// 09 — Synthetic insight goes into a real conversation.
{
 const g=group();groups.push(g);plinth(g,3.1);const a=person('olive',1),b=person('blue',2);a.position.set(-1.4,0,.5);b.position.set(1.4,0,-.2);a.scale.setScalar(1.45);b.scale.setScalar(1.45);g.add(a,b);
 const ring=mesh(new THREE.TorusGeometry(.7,.06,12,64),mats.olive,g,0,2.7,0);const check=label('✓',.8,.8,null,C.olive,700);check.position.set(0,2.7,.05);g.add(check);
 anim.push((u,t)=>{g.rotation.y=-.13+u*.25;a.rotation.y=.25;b.rotation.y=-.3;ring.rotation.y=Math.sin(t)*.12;});
}
// 10 — Return to a community, hold a confident end frame.
{
 const g=group();groups.push(g);const people=[];for(let i=0;i<7;i++){const p=person(['sage','blue','clay','gold','lilac','sage','blue'][i],i);g.add(p);people.push(p);}const tile=box(g,2,2,.28,0,2.8,0,mats.olive,.20);const icon=await texLoader.loadAsync('../assets/gnomi-icon-reversed.svg');icon.colorSpace=THREE.SRGBColorSpace;mesh(new THREE.PlaneGeometry(1.25,1.25),new THREE.MeshBasicMaterial({map:icon,transparent:true,toneMapped:false}),g,0,2.8,.15);
 anim.push((u,t)=>{g.rotation.y=-.1+u*.18;people.forEach((p,i)=>{const a=i*Math.PI*2/7;p.position.set(Math.cos(a)*2.8,0,Math.sin(a)*1.8);p.scale.setScalar(.72);});});
}
const scenes=[
{start:0,end:5.4,eyebrow:'A FRESH PERSPECTIVE',title:'You know\nyour product.',body:'What happens when someone\nsees it for the first time?',chips:[],fine:''},
{start:5.4,end:11.4,eyebrow:'MEET GNOMI',title:'Perspective\nbefore you ship.',body:'Social simulation\nfor product teams.',chips:['Simulated users','Inspectable evidence'],fine:''},
{start:11.4,end:21.4,eyebrow:'01 / DEFINE YOUR AUDIENCE',title:'Different people.\nDifferent needs.',body:'Roles, languages, devices, and goals.\nIndividual perspectives.',chips:['Roles','Languages','Devices','Goals'],fine:'Simulated users'},
{start:21.4,end:30.2,eyebrow:'02 / SHARE YOUR STARTING POINT',title:'Share what\nyou’re building.',body:'Your idea. Your staging app.\nYour Figma design.',chips:[],fine:'Illustrative inputs'},
{start:30.2,end:38.5,eyebrow:'03 / FOLLOW THE EXPERIENCE',title:'Clicks. Pauses.\nFriction.',body:'Follow what each persona did,\nthought, and encountered.',chips:['Actions','Thoughts','Evidence'],fine:'Actual Gnomi interface · demo activity'},
{start:38.5,end:51.3,eyebrow:'04 / SEE HOW OPINIONS FORM',title:'Opinions\ntravel.',body:'Posts. Replies. Reactions.\nWatch opinions travel and change.',chips:['First-hand experience','Social influence'],fine:'Illustrative social simulation'},
{start:51.3,end:63.6,eyebrow:'05 / REVIEW THE EVIDENCE',title:'From friction\nto a next step.',body:'Ranked findings with evidence\nand suggested changes.',chips:['HTML','PDF','Markdown'],fine:'Example from Gnomi’s documented test-app report · 16 October 2026'},
{start:63.6,end:70.6,eyebrow:'YOUR WORKSPACE. YOUR CHOICES.',title:'Runs locally.\nUses your keys.',body:'Projects on your machine.\nModel inputs sent to your\nconfigured provider.',chips:['Local projects','Your model provider'],fine:''},
{start:70.6,end:77.5,eyebrow:'TURN INSIGHT INTO RESEARCH',title:'A hypothesis.\nThen a human.',body:'Use simulated findings to decide\nwhat to validate with real people.',chips:[],fine:'Synthetic findings · validate with real people'},
{start:77.5,end:87,eyebrow:'GNOMI',title:'Know what\nto test next.',body:'Find the friction.\nFollow the conversation.',chips:['Perspective before you ship.'],fine:'Simulated users. Evidence to investigate.',dark:true}
];
let current=-1;const $=s=>document.querySelector(s);
window.setFrame=async(frame)=>{const t=frame/fps;let idx=scenes.findIndex(s=>t>=s.start&&t<s.end);if(idx<0)idx=9;const s=scenes[idx],local=t-s.start,u=local/(s.end-s.start);
 if(idx!==current){current=idx;groups.forEach((g,i)=>g.visible=i===idx);$('#stage').className=(s.dark?'dark ':'')+(idx===9?'outro':'');$('#logo').src='../assets/gnomi-logo'+(s.dark?'-reversed':'')+'.svg';$('#eyebrow').textContent=s.eyebrow.replace(/^\d{2} \/ /,'');$('#title').textContent=s.title;$('#body').textContent=s.body;$('#fine').textContent=s.fine;}
 const ease=1-Math.pow(1-Math.min(local/.65,1),3);$('#copy').style.opacity=String(ease);$('#copy').style.transform=`translateY(${(1-ease)*28}px)`;$('#fine').style.opacity=String(ease);
 anim[idx](u,t);groups[idx].position.y=(1-ease)*-.35;groups[idx].scale.setScalar(.94+ease*.06);
 camera.position.set(.35*Math.sin(t*.18),5.1+(idx===5?.7:0),14.2-u*.85);camera.lookAt(0,1.6,0);
 $('#quote').style.opacity='0';if(idx===5&&local>4){$('#quote').innerHTML='<small>SIMULATED REACTION</small>“I ran into that too.”';$('#quote').style.opacity=String(Math.min((local-4)/.5,1)*Math.min((s.end-t)/.6,1));}
 const fade=idx===9&&t>85.8?(t-85.8)/1.2:0;$('#wash').style.opacity=String(fade*.06);renderer.render(scene,camera);return idx;};
window.exportModels=async()=>{const g=new THREE.Group();for(let i=0;i<5;i++){const p=person(['olive','blue','clay','gold','lilac'][i],i);p.position.x=(i-2)*1.5;g.add(p);}const result=await new GLTFExporter().parseAsync(g,{binary:true});return Array.from(new Uint8Array(result));};
await window.setFrame(0);window.ready=true;
if(new URLSearchParams(location.search).has('play')){const start=performance.now();function play(){window.setFrame(Math.min((performance.now()-start)/1000*fps,duration*fps-1));requestAnimationFrame(play);}play();}
