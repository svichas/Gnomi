"""Rebuild the input-options narration pickup without changing later timing."""
from pathlib import Path
import json, re, subprocess
root=Path(__file__).resolve().parents[1]
old='Point them at your staging app. Record a login, choose the allowed hosts, and set a budget. Each persona tries to get something done.'
new='Share your idea, staging app, or your Figma design. Set a goal and a budget. Each persona explores from a different perspective.'
filters='[0:a]asplit=2[pre][post];[pre]atrim=end=20.4,asetpts=PTS-STARTPTS[a];[post]atrim=start=29.2,asetpts=PTS-STARTPTS[c];[1:a]volume=4.2dB,afade=t=in:d=0.01,apad=whole_dur=8.8,atrim=duration=8.8,afade=t=out:st=8.66:d=0.14,asetpts=PTS-STARTPTS[b];[a][b][c]concat=n=3:v=0:a=1[out]'
subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(root/'assets/narration-4.mp3'),'-i',str(root/'assets/input-options-pickup.mp3'),'-filter_complex',filters,'-map','[out]','-ar','48000','-c:a','pcm_s16le',str(root/'assets/narration-revised.wav')],check=True)
p=root/'narration.txt';p.write_text(p.read_text().replace(old,new))
p=root/'source/production.json';d=json.loads(p.read_text());d['script']=d['script'].replace(old,new)
t=json.loads((root/'source/input-options-transcript.json').read_text())
words=[dict(w,start=round(w['start']+20.4,6),end=round(w['end']+20.4,6)) for w in t['words'] if not w['text'].startswith('[')]
d['words']=[w for w in d['words'] if w['start']<20.4]+words+[w for w in d['words'] if w['start']>=29.2]
d['narration']='narration-revised.wav';d['input_options_pickup']={'asset':'input-options-pickup.mp3','source_start':20.4,'source_end':29.2,'gain_db':4.2,'generation_id':t.get('generation_id')}
p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
# Keep all unrelated subtitle cues exactly as they were.
p=root/'Gnomi.en.srt';s=p.read_text();s=re.sub(r'^9\n.*?(?=^12\n)', '''9
00:00:21,432 --> 00:00:24,912
Share your idea, staging app,
or your Figma design.

10
00:00:25,432 --> 00:00:26,832
Set a goal and a budget.

11
00:00:27,192 --> 00:00:29,832
Each persona explores from
a different perspective.

''',s,count=1,flags=re.S|re.M);p.write_text(s)
print('Rebuilt narration, script, word timings, and subtitles for the revised section.')
