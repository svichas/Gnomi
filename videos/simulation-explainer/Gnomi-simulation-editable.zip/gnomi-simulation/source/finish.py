"""Create the delivery MP4 with optional captions and chapter metadata.
Use --master PATH for a Synthcut export, or omit to mix the original stems.
"""
import argparse,pathlib,subprocess
root=pathlib.Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--master',type=pathlib.Path);args=p.parse_args()
def run(a):subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error',*map(str,a)],check=True)
master=args.master
if master is None:
 master=root/'source/local-master.mp4'
 run(['-i',root/'visuals.mp4','-i',root/'assets/voice.flac','-i',root/'assets/music-bed.flac','-i',root/'assets/transitions.flac','-filter_complex','[1:a][2:a][3:a]amix=inputs=3:normalize=0,loudnorm=I=-16:TP=-1.5:LRA=11[a]','-map','0:v','-map','[a]','-c:v','copy','-c:a','aac','-b:a','256k','-ar','48000','-t','200',master])
run(['-i',master,'-i',root/'Gnomi-simulation.en.srt','-i',root/'source/chapters.ffmetadata','-map','0:v:0','-map','0:a:0','-map','1:0','-map_metadata','2','-map_chapters','2','-c:v','copy','-c:a','copy','-c:s','mov_text','-metadata:s:s:0','language=eng','-metadata:s:s:0','title=English','-disposition:s:0','0','-movie_timescale','1000','-video_track_timescale','24000','-movflags','+faststart',root/'Gnomi-simulation.mp4'])
print(root/'Gnomi-simulation.mp4')
