"""Build exact-length separate audio stems with standard-library PCM assembly."""
import array,json,pathlib,subprocess,wave,sys
root=pathlib.Path(__file__).resolve().parent.parent
assets=root/'assets';source=root/'source';rate=48000;duration=200;frames=rate*duration

def ff(args):subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error',*map(str,args)],check=True)
def pcm(file,filter):
 return subprocess.check_output(['ffmpeg','-v','error','-i',str(file),'-af',filter,'-ar',str(rate),'-ac','2','-f','s16le','-'])
def stem(name,data):
 path=source/(name+'.wav')
 with wave.open(str(path),'wb') as w:w.setparams((2,2,rate,0,'NONE','not compressed'));w.writeframes(data)
 ff(['-i',path,'-c:a','flac','-compression_level','5',assets/(name+'.flac')]);path.unlink()

voice=pcm(assets/'narration.mp3','loudnorm=I=-16:TP=-1.8:LRA=11')
lead=round(.65*rate)*4
raw=(b'\0'*lead+voice)[:frames*4];raw+=b'\0'*(frames*4-len(raw));stem('voice',raw)
ff(['-i',assets/'music.mp3','-i',assets/'music.mp3','-i',assets/'music.mp3','-filter_complex','[0:a][1:a]acrossfade=d=3:c1=tri:c2=tri[a];[a][2:a]acrossfade=d=3:c1=tri:c2=tri,loudnorm=I=-33:TP=-9:LRA=9,atrim=duration=200,afade=t=in:d=2,afade=t=out:st=196:d=4[out]','-map','[out]','-t','200','-ar','48000','-ac','2','-c:a','flac',assets/'music-bed.flac'])
fx=array.array('h');fx.frombytes(pcm(assets/'whoosh.mp3','atrim=duration=1.8,afade=t=out:st=1.3:d=0.5,volume=0.07'))
track=array.array('h',[0])*(frames*2)
if sys.byteorder!='little':fx.byteswap()
for scene in json.loads((source/'timing.json').read_text())[1:]:
 start=round(max(0,scene['start']-.3)*rate)*2
 for i,v in enumerate(fx):
  if start+i<len(track):track[start+i]=max(-32768,min(32767,track[start+i]+v))
if sys.byteorder!='little':track.byteswap()
stem('transitions',track.tobytes())
for name in ['voice','music-bed','transitions']:
 d=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(assets/(name+'.flac'))]))
 assert abs(d-duration)<.01,(name,d)
print('Verified all three stems: stereo, 48 kHz, exactly 200 seconds.')
