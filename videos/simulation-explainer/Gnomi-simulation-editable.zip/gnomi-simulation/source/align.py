"""Align the authored chapters and readable subtitle cues to the selected take."""
import json,re,pathlib
root=pathlib.Path(__file__).resolve().parent.parent
paras=root.joinpath('narration.txt').read_text().strip().split('\n\n')
words=[w for w in json.loads(root.joinpath('source/transcript.json').read_text())['words'] if not w['text'].startswith('[')]
normalize=lambda s:re.sub(r'[^a-z0-9]','',s.lower())
assert [normalize(s) for p in paras for s in p.split()]==[normalize(w['text']) for w in words], 'Transcript differs from the approved script'
offset=.65; pos=0; timing=[]
for i,p in enumerate(paras):
 count=len(p.split());part=words[pos:pos+count]
 start=0 if i==0 else round(max(0,part[0]['start']+offset-.22)*24)/24
 timing.append({'start':start,'end':None,'text':p});pos+=count
for i in range(len(timing)-1):timing[i]['end']=timing[i+1]['start']
timing[-1]['end']=200
root.joinpath('source/timing.json').write_text(json.dumps(timing,indent=2)+'\n')
def stamp(t):
 ms=round(t*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000)
 return f'{h:02}:{m:02}:{s:02},{ms:03}'
cues=[];group=[]
for w in words:
 if group and (len(' '.join(x['text'] for x in group)+' '+w['text'])>76 or w['end']-group[0]['start']>4.3):cues.append(group);group=[]
 group.append(w)
 if w['text'].endswith(('.', '?', '!')):cues.append(group);group=[]
if group:cues.append(group)
blocks=[]
for i,cue in enumerate(cues):
 s=' '.join(w['text'] for w in cue)
 if len(s)>44:
  options=[m.start() for m in re.finditer(' ',s)];at=min(options,key=lambda x:abs(x-len(s)/2));s=s[:at]+'\n'+s[at+1:]
 end=cue[-1]['end']+offset+.06
 if i+1<len(cues):end=min(end,cues[i+1][0]['start']+offset-.025)
 blocks.append(f'{i+1}\n{stamp(cue[0]["start"]+offset)} --> {stamp(end)}\n{s}\n')
root.joinpath('Gnomi-simulation.en.srt').write_text('\n'.join(blocks))
chapters=json.loads(root.joinpath('source/scenes.json').read_text())
meta=';FFMETADATA1\ntitle=Gnomi — Inside the simulation\nartist=Gnomi\ncomment=Illustrative simulation explainer based on docs/new_simulation.md, 18 October 2026\n'
for chapter,s in zip(chapters,timing):meta+=f'\n[CHAPTER]\nTIMEBASE=1/1000\nSTART={round(s["start"]*1000)}\nEND={round(s["end"]*1000)}\ntitle={chapter["chapter"]}\n'
root.joinpath('source/chapters.ffmetadata').write_text(meta)
print(json.dumps([{'chapter':c['chapter'],'start':s['start'],'end':s['end']} for c,s in zip(chapters,timing)],indent=2))
print(f'{len(words)} aligned words, {len(cues)} subtitle cues')
