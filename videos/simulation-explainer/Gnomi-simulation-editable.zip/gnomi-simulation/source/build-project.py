"""Build a dedicated, portable Synthcut edit without modifying the shared editor."""
import json,pathlib,time,subprocess
root=pathlib.Path(__file__).resolve().parent.parent
spec=json.loads((root/'source/scenes.json').read_text());timing=json.loads((root/'source/timing.json').read_text());now=round(time.time()*1000)
assets=[]
for key,file,video in [('picture','visuals.mp4',True),('voice','assets/voice.flac',False),('music','assets/music-bed.flac',False),('effects','assets/transitions.flac',False)]:
 p=root/file;probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]));stream=probe['streams'][0]
 a={'id':'gnomi_simulation_'+key,'path':str(p),'name':p.name,'duration':float(probe['format']['duration']),'width':1920 if video else 0,'height':1080 if video else 0,'fps':24,'hasVideo':video,'hasAudio':not video,'addedAt':now}
 a['videoCodec' if video else 'audioCodec']=stream['codec_name'];assets.append(a)
tracks=[{'id':'gnomi_simulation_picture','kind':'video','index':0,'name':'3D scenes + explanatory diagrams','clips':[{'id':f'gnomi_simulation_scene_{i}','assetId':assets[0]['id'],'startFrame':round(s['start']*24),'sourceInFrame':round(s['start']*24),'sourceOutFrame':round(s['end']*24)} for i,s in enumerate(timing)]}]
for i,name in enumerate(['Narration · Justin Case','Music · quiet crossfaded bed','Transitions · subtle whooshes'],1):
 tracks.append({'id':f'gnomi_simulation_audio_{i}','kind':'audio','index':i,'name':name,'clips':[{'id':f'gnomi_simulation_audio_clip_{i}','assetId':assets[i]['id'],'startFrame':0,'sourceInFrame':0,'sourceOutFrame':4800}]})
data={'id':'gnomi_simulation_explainer_20261018','name':'Gnomi — Inside the simulation','width':1920,'height':1080,'fps':24,'assets':assets,'tracks':tracks,'revision':1,'schemaVersion':3,'createdAt':now,'updatedAt':now,'markers':[{'frame':round(s['start']*24),'name':c['chapter'],'color':'#58684e','note':c['note']} for c,s in zip(spec,timing)]}
for t in tracks:
 for clip in t['clips']:assert clip['sourceOutFrame']>clip['sourceInFrame'] and clip['startFrame']>=0
assert sum(c['sourceOutFrame']-c['sourceInFrame'] for c in tracks[0]['clips'])==4800
out=root/'Gnomi-simulation-edit.aive';out.write_text(json.dumps(data,indent=2)+'\n');print(out)
