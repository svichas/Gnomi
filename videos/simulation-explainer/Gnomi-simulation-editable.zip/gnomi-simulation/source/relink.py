"""Relink an extracted Synthcut project to this bundle's local files."""
import json,pathlib
root=pathlib.Path(__file__).resolve().parent.parent
p=root/'Gnomi-simulation-edit.aive';data=json.loads(p.read_text())
def walk(value):
 if isinstance(value,dict):
  for k,v in value.items():
   if isinstance(v,str) and ('/simulation-explainer/' in v):
    candidate=root/v.split('/simulation-explainer/',1)[1]
    if candidate.is_file():value[k]=str(candidate)
   else:walk(v)
 elif isinstance(value,list):
  for v in value:walk(v)
walk(data)
out=root/'Gnomi-simulation-edit-relocated.aive';out.write_text(json.dumps(data,indent=2)+'\n');print(out)
