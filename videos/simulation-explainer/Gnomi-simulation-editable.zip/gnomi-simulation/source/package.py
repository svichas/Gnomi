"""Bundle the self-contained edit without caches, duplicate exports or node_modules."""
import pathlib,zipfile
root=pathlib.Path(__file__).resolve().parent.parent
names=['Gnomi-simulation-edit.aive','Gnomi-simulation.en.srt','narration.txt','production-notes.txt','storyboard.jpg','cover.jpg','visuals.mp4']
files=[root/n for n in names]
files+=sorted(p for p in (root/'assets').iterdir() if p.suffix in {'.flac','.mp3','.svg','.woff2','.glb','.txt'})
files+=sorted(p for p in (root/'source').iterdir() if p.suffix in {'.py','.js','.mjs','.html','.json','.md','.ffmetadata'})
archive=root/'Gnomi-simulation-editable.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,'gnomi-simulation/'+str(p.relative_to(root)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(f'{archive}: {len(files)} files, {archive.stat().st_size/1024/1024:.1f} MiB')
