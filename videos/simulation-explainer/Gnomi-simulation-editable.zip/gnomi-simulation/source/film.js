import * as T from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
import {GLTFExporter} from 'three/addons/exporters/GLTFExporter.js';
const scenes=await (await fetch('./scenes.json')).json();
const timing=await (await fetch('./timing.json')).json();
await document.fonts.load('450 80px Inter'); await document.fonts.load('500 26px Inter');
const canvas=document.querySelector('#film'),ctx=canvas.getContext('2d');
const C={paper:'#f6f5f0',ink:'#222823',olive:'#58684e',sage:'#e7ebdd',stone:'#686d65',line:'#d8dcd2',blue:'#56768a',plum:'#8a6a83',gold:'#a27b36',teal:'#417f78'};
const colors=[C.olive,C.blue,C.plum,C.gold,C.teal];
const clamp=x=>Math.max(0,Math.min(1,x)); const ease=x=>1-(1-clamp(x))**3;
const lerp=(a,b,u)=>a+(b-a)*u;
function font(size=28,weight=400){ctx.font=`${weight} ${size}px Inter`;ctx.textBaseline='top';}
function text(s,x,y,size=28,color=C.ink,weight=400,lh=1.2){font(size,weight);ctx.fillStyle=color;String(s).split('\n').forEach((l,i)=>ctx.fillText(l,x,y+i*size*lh));}
function rect(x,y,w,h,fill,r=12,stroke){ctx.beginPath();ctx.roundRect(x,y,w,h,r);if(fill){ctx.fillStyle=fill;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=2;ctx.stroke();}}
function line(x1,y1,x2,y2,color=C.line,width=3,dash=[]){ctx.beginPath();ctx.strokeStyle=color;ctx.lineWidth=width;ctx.setLineDash(dash);ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();ctx.setLineDash([]);}
function dot(x,y,r,color){ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fillStyle=color;ctx.fill();}
function arrow(x1,y1,x2,y2,color=C.olive,width=3){line(x1,y1,x2,y2,color,width);const a=Math.atan2(y2-y1,x2-x1);ctx.beginPath();ctx.moveTo(x2,y2);ctx.lineTo(x2-12*Math.cos(a-.5),y2-12*Math.sin(a-.5));ctx.lineTo(x2-12*Math.cos(a+.5),y2-12*Math.sin(a+.5));ctx.closePath();ctx.fillStyle=color;ctx.fill();}
function pill(s,x,y,w,color=C.olive,bg=C.sage){rect(x,y,w,42,bg,21);text(s,x+18,y+9,20,color,500);}
function iconPerson(x,y,c,s=1){dot(x,y,14*s,c);rect(x-20*s,y+20*s,40*s,47*s,c,20*s);}
function image(src){return new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>resolve(im);im.onerror=reject;im.src=src;});}
const logo=await image('../assets/gnomi-logo.svg'),logoLight=await image('../assets/gnomi-logo-reversed.svg');
const renderer=new T.WebGLRenderer({antialias:true,alpha:true,preserveDrawingBuffer:true});renderer.setSize(1180,850);renderer.setPixelRatio(1);renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.08;
const world=new T.Scene(),camera=new T.PerspectiveCamera(36,1180/850,.1,100);camera.position.set(0,5.4,14);camera.lookAt(0,1,0);
const pmrem=new T.PMREMGenerator(renderer);world.environment=pmrem.fromScene(new RoomEnvironment(),.04).texture;world.environmentIntensity=.35;
world.add(new T.HemisphereLight(0xffffff,0xbdb8a9,2));const sun=new T.DirectionalLight(0xfff5e7,2.8);sun.position.set(-5,9,7);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);Object.assign(sun.shadow.camera,{left:-8,right:8,top:8,bottom:-8});sun.shadow.normalBias=.05;sun.shadow.bias=-.0002;sun.shadow.radius=4;world.add(sun);
const fill=new T.DirectionalLight(0xd4dfcb,1.1);fill.position.set(7,4,-3);world.add(fill);
const floor=new T.Mesh(new T.PlaneGeometry(100,100),new T.ShadowMaterial({opacity:.09}));floor.rotation.x=-Math.PI/2;floor.position.y=-.12;floor.receiveShadow=true;world.add(floor);
const material=c=>new T.MeshStandardMaterial({color:c,roughness:.75,metalness:0});const mats=Object.fromEntries(Object.entries(C).map(([k,v])=>[k,material(v)])),white=material('#fffef9');
function mesh(g,geo,mat,x=0,y=0,z=0){const m=new T.Mesh(geo,mat);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;g.add(m);return m;}
function box(g,w,h,d,x,y,z,m=white,r=.1){return mesh(g,new RoundedBoxGeometry(w,h,d,3,r),m,x,y,z);}
function ball(g,r,x,y,z,m){return mesh(g,new T.SphereGeometry(r,28,20),m,g?x:0,y,z);}
const bodyGeo=new T.LatheGeometry(new T.SplineCurve([[0,.02],[.25,.02],[.35,.08],[.36,.19],[.32,.55],[.27,.87],[.18,1.05],[0,1.10]].map(p=>new T.Vector2(...p))).getPoints(48).map(p=>new T.Vector2(Math.max(0,p.x),p.y)),40);
const headGeo=new T.SphereGeometry(.25,32,24);
function person(color=C.olive,i=0){const g=new T.Group();g.name=`Synthetic persona ${i+1}`;const m=material(color);mesh(g,bodyGeo,m).scale.set([1,1.08,.95][i%3],[1,.95,1.05][i%3],.87);mesh(g,headGeo,m,0,1.41,0);return g;}
function plinth(g,x=0,z=0,r=3){return mesh(g,new T.CylinderGeometry(r,r,.14,80),mats.sage,x,-.02,z);}
function cardTexture(title,lines=[],accent=C.olive){const c=document.createElement('canvas');c.width=900;c.height=600;const a=c.getContext('2d');a.fillStyle='#ebece3';a.fillRect(0,0,900,600);a.fillStyle=accent;a.fillRect(0,0,900,15);a.fillStyle=C.ink;a.font='500 76px Inter';a.fillText(title,55,110);a.font='400 46px Inter';lines.forEach((l,i)=>a.fillText(l,55,195+i*61));const tex=new T.CanvasTexture(c);tex.colorSpace=T.SRGBColorSpace;return tex;}
function card(g,title,lines,w=2.5,h=1.67,color=C.olive){const b=new T.Group();box(b,w,h,.09,0,0,0,white,.06);mesh(b,new T.PlaneGeometry(w-.04,h-.04),new T.MeshBasicMaterial({map:cardTexture(title,lines,color),toneMapped:false}),0,0,.052);g.add(b);return b;}
function path(g,pts,color=C.olive,r=.025){const curve=new T.CatmullRomCurve3(pts.map(p=>new T.Vector3(...p)));const m=mesh(g,new T.TubeGeometry(curve,28,r,7,false),material(color));const tip=new T.Mesh(new T.ConeGeometry(r*3.1,r*7.2,12),material(color));tip.position.copy(curve.getPoint(.76));tip.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),curve.getTangent(.76));m.add(tip);return {mesh:m,curve};}
const groups=Array(12).fill(null),animate=Array(12).fill(()=>{});
function group(i){const g=new T.Group();g.name=scenes[i].chapter;world.add(g);g.visible=false;groups[i]=g;return g;}
const load=new T.TextureLoader();const icon=await load.loadAsync('../assets/gnomi-icon-reversed.svg');icon.colorSpace=T.SRGBColorSpace;
function brandTile(g){const o=new T.Group();box(o,1.7,1.7,.3,0,0,0,mats.olive,.24);mesh(o,new T.PlaneGeometry(1.15,1.15),new T.MeshBasicMaterial({map:icon,transparent:true,toneMapped:false}),0,0,.16);g.add(o);return o;}
// Sculptural overview: a contained world of people, product inputs, and evidence.
{
 const g=group(0);plinth(g,0,0,3.5);const tile=brandTile(g);tile.position.set(0,2.45,-.6);const ring=mesh(g,new T.TorusGeometry(1.75,.055,16,96),mats.olive,0,2.45,-.8);
 const ps=[];for(let i=0;i<5;i++){const p=person(colors[i],i);p.scale.setScalar(.79);g.add(p);ps.push(p);}
 const doc=card(g,'Evidence',['Observation','Action + source'],1.8,1.2);doc.position.set(2.8,2.0,.5);doc.rotation.y=-.22;
 animate[0]=(u,t)=>{g.rotation.y=-.15+u*.25;ps.forEach((p,i)=>{const a=i*2*Math.PI/5+u*.2;p.position.set(Math.cos(a)*2.6,0,Math.sin(a)*2.0);});ring.rotation.y=Math.sin(t*.3)*.15;tile.position.y=2.45+Math.sin(t*.7)*.035;};
}
// Matched A/B worlds: same people and ties, independent environments.
{
 const g=group(1);const sets=[];for(let k=0;k<2;k++){const set=new T.Group();set.position.x=k?2.25:-2.25;g.add(set);plinth(set,0,0,1.85);const c=card(set,k?'Product B':'Product A',['Same experiment','Separate state'],2.55,1.7,k?C.blue:C.olive);c.position.set(0,2.4,-.6);c.rotation.y=k?-.15:.15;
  for(let j=0;j<3;j++){const p=person(colors[j],j);p.scale.setScalar(.63);p.position.set((j-1)*1.15,0,.75+Math.abs(j-1)*-.2);set.add(p);}sets.push(set);}
 animate[1]=(u,t)=>{g.rotation.y=-.1+u*.18;sets.forEach((s,k)=>{s.position.y=(1-ease(u*5-k*.3))*.4;});};
}
// Directed social graph. Packets travel from post authors toward followers.
{
 const g=group(2),positions=[],ps=[],links=[];plinth(g,0,0,3.7);
 for(let i=0;i<9;i++){const p=person(colors[i%5],i);const pos=[(i%3-1)*2.35,0,(Math.floor(i/3)-1)*2];p.position.set(...pos);p.scale.setScalar(.72);g.add(p);positions.push(pos);ps.push(p);}
 [[0,1],[1,2],[0,3],[3,4],[4,5],[6,4],[4,8],[7,8]].forEach(([a,b],i)=>{const x=positions[a],y=positions[b];const p=path(g,[[x[0],.6,x[2]],[(x[0]+y[0])/2,.85,(x[2]+y[2])/2],[y[0],.6,y[2]]],colors[a%5],.022);links.push({...p,bead:ball(g,.085,0,0,0,mats.paper)});});
 animate[2]=(u,t)=>{g.rotation.y=-.28+u*.28;ps.forEach((p,i)=>p.scale.setScalar(.72*(.7+.3*ease(u*6-i*.18))));links.forEach((l,i)=>l.bead.position.copy(l.curve.getPoint((t*.12+i*.17)%1)));};
}
// Product phase: own observations and a bounded record of evidence.
{
 const g=group(4);plinth(g,0,0,3.5);const c=document.createElement('canvas');c.width=1200;c.height=780;const a=c.getContext('2d');a.fillStyle=C.paper;a.fillRect(0,0,1200,780);a.fillStyle=C.ink;a.fillRect(0,0,1200,88);a.fillStyle=C.paper;a.font='500 31px Inter';a.fillText('Example product',50,56);a.fillStyle=C.ink;a.font='500 56px Inter';a.fillText('Choose a workspace',66,193);
 [0,1,2].forEach(i=>{a.fillStyle=i?C.sage:'#d6ddce';a.beginPath();a.roundRect(65+i*370,247,335,270,16);a.fill();a.fillStyle=colors[i];a.beginPath();a.arc(230+i*370,346,50,0,7);a.fill();a.fillStyle=C.ink;a.font='400 27px Inter';a.fillText(['Personal','Team','Research'][i],154+i*370,462);});a.fillStyle=C.olive;a.beginPath();a.roundRect(823,624,315,88,12);a.fill();a.fillStyle=C.paper;a.font='500 30px Inter';a.fillText('Continue →',895,679);
 const tex=new T.CanvasTexture(c);tex.colorSpace=T.SRGBColorSpace;box(g,5.8,3.85,.15,.3,2.45,-.65,mats.ink,.10);mesh(g,new T.PlaneGeometry(5.6,3.64),new T.MeshBasicMaterial({map:tex,toneMapped:false}),.3,2.45,-.56);
 const p=person(C.olive,0);p.position.set(-2.6,0,1.7);p.scale.setScalar(1.05);g.add(p);const cursor=mesh(g,new T.ConeGeometry(.16,.42,3),mats.olive,1.95,1.5,-.25);cursor.rotation.z=.6;
 const ev=card(g,'Step evidence',['What was visible','Action + source ID'],2.5,1.67,C.blue);ev.position.set(2.7,1.3,1.45);ev.rotation.y=-.25;
 animate[4]=(u,t)=>{g.rotation.y=-.13+u*.18;cursor.position.x=lerp(-.2,2.0,ease(u*2));cursor.position.y=lerp(2.7,1.35,ease(u*2));ev.position.y=1.3+.06*Math.sin(t*.7);};
}
// Social phase: distinct feeds and optional public action.
{
 const g=group(5);plinth(g,0,0,3.7);const positions=[[-2.6,0,1.25],[0,0,2.2],[2.6,0,1.25],[-1.65,0,-1.65],[1.65,0,-1.65]];const links=[];
 positions.forEach((p,i)=>{const ob=person(colors[i],i);ob.position.set(...p);ob.scale.setScalar(.78);g.add(ob);});
 [[0,1],[0,3],[1,2],[3,4]].forEach(([a,b],i)=>{const x=positions[a],y=positions[b];const l=path(g,[[x[0],1.15,x[2]],[(x[0]+y[0])/2,1.9,(x[2]+y[2])/2],[y[0],1.15,y[2]]],colors[i],.025);links.push({...l,bead:ball(g,.095,0,0,0,mats.paper)});});
 const feed=card(g,'Selected feed',['Permitted posts','Own prior evidence'],3.1,2.06);feed.position.set(0,3.5,-.6);
 animate[5]=(u,t)=>{g.rotation.y=-.2+u*.27;links.forEach((l,i)=>{const v=clamp((u-.18-i*.08)*2.5);l.mesh.visible=u>.15+i*.05;l.bead.visible=v>0&&v<1;l.bead.position.copy(l.curve.getPoint(v));});};
}
// Evidence provenance: a direct path and a second, social path.
{
 const g=group(7);plinth(g,0,0,3.8);
 const c=card(g,'Product observation',['The next step is hidden'],3.9,2.6);c.position.set(0,3.15,-1.3);
 const p=person(C.olive,0);p.position.set(-2.25,0,1);g.add(p);const q=person(C.blue,1);q.position.set(2.25,0,1);g.add(q);
 const direct=path(g,[[0,2.3,-1.1],[-2,2,-.2],[-2.25,1.2,1]],C.olive,.04);const heard=path(g,[[-2.1,1.5,1],[0,2.1,1.6],[2.1,1.5,1]],C.blue,.03);const bead=ball(g,.11,0,0,0,mats.paper);
 animate[7]=(u,t)=>{g.rotation.y=-.10+u*.16;bead.position.copy((u<.45?direct:heard).curve.getPoint(u<.45?clamp(u/.45):clamp((u-.45)/.5)));};
}
// Two computational roles, visually distinct but joined in one runtime.
{
 const g=group(9);plinth(g,0,0,3.6);const a=card(g,'Deterministic code',['Select + validate','Account + measure'],3.6,2.4);a.position.set(-1.7,2.3,0);a.rotation.y=.16;
 const b=card(g,'Language models',['Interpret content','Propose behavior'],3.6,2.4,C.blue);b.position.set(1.8,2.3,-.5);b.rotation.y=-.18;
 const pipe=path(g,[[-1.5,.8,.2],[0,.5,1],[1.6,.8,0]],C.olive,.055);const bead=ball(g,.13,0,0,0,mats.olive);
 for(let i=0;i<5;i++)box(g,.40,.27,.55,-2.3+i*.48,.2,1.45,i<3?mats.olive:mats.sage,.04);
 animate[9]=(u,t)=>{g.rotation.y=-.08+u*.16;bead.position.copy(pipe.curve.getPoint((t*.18)%1));};
}
{
 const g=group(11);plinth(g,0,0,3.4);const tile=brandTile(g);tile.position.set(0,2.9,-.6);tile.scale.setScalar(1.3);
 const people=[];for(let i=0;i<3;i++){const p=person(colors[i],i);p.position.set((i-1)*2.05,0,1.1+Math.abs(i-1)*-.3);g.add(p);people.push(p);}
 animate[11]=(u,t)=>{g.rotation.y=-.12+u*.18;tile.position.y=2.9+Math.sin(t*.6)*.04;};
}
function header(dark=false){ctx.drawImage(dark?logoLight:logo,104,48,156,48);}
function introText(index,u,full=false){const s=scenes[index],e=ease(u*9);ctx.save();ctx.globalAlpha=e;ctx.translate(0,(1-e)*24);text(s.kicker,104,full?178:230,18,C.olive,500);text(s.title,100,full?226:287,full?68:74,C.ink,450,1.08);text(s.body,104,full?327:(index===2?486:492),27,C.stone,400,1.46);ctx.restore();}
function footer(index){text(scenes[index].note,104,1000,17,C.stone,400);}
function splitScene(index,u,t){introText(index,u);renderer.render(world,camera);ctx.drawImage(renderer.domElement,720,125,1180,850);
 if(index===0){pill('Observe',104,672,130);line(252,693,280,693,C.olive,2);pill('Interact',296,672,134);line(450,693,478,693,C.olive,2);pill('Inspect',494,672,128);}
 if(index===1){['Question + outcomes','Population + network','Version + limits'].forEach((s,i)=>{if(u>i*.09){line(106,648+i*58,126,648+i*58,C.olive,3);text(s,144,632+i*58,25,C.ink,400);}});}
 if(index===2){['Goal: finish a task','Familiarity: new or experienced','Constraint: time and attention'].forEach((s,i)=>{ctx.globalAlpha=ease(u*6-i*.2);text(s,104,642+i*58,25,i===0?C.olive:C.stone,400);});ctx.globalAlpha=1;}
 if(index===4){['Observe','Propose','Validate + record'].forEach((s,i)=>{dot(119,650+i*64,6,i===Math.floor(u*3)%3?C.olive:C.line);text(s,144,631+i*64,25,C.ink);});}
 if(index===5){pill('Read',104,654,100);pill('Post / reply / react',222,654,242);pill('No public action',104,716,236,C.blue,'#e5ebef');}
 if(index===7){dot(114,660,7,C.olive);text('Firsthand',140,640,28,C.olive,500);text('Drives ranking counts',140,680,23,C.stone);dot(114,762,7,C.blue);text('Heard first',140,742,28,C.blue,500);text('Visible alongside the finding',140,782,23,C.stone);}
 if(index===9){['Budget','Retries','Model settings'].forEach((s,i)=>pill(s,104+i*170,676,i===2?190:150));text('Measure cost, time, and behavioral quality.',104,754,22,C.stone);}
 if(index===11){text('Implemented on the simulation branch',104,632,22,C.olive,500);text('Runtime · social corrections · evaluation harness',104,671,21,C.stone);text('Human behavioral validation: not yet done',104,743,23,C.ink,500);text('Run store + recovery: planned',104,788,21,C.stone);}
}
function architecture(u,t){introText(3,u,true);const xs=[104,662,1220];const labels=[['App','Controls + results'],['Engine','Authoring + imports'],['Simulation','Execution + evidence']];
 xs.forEach((x,i)=>{const e=ease(u*7-i*.25);ctx.globalAlpha=e;rect(x,461+(1-e)*18,470,202,i===2?C.olive:'#ffffff',12,i===2?null:C.line);text(labels[i][0],x+32,493,40,i===2?C.paper:C.ink,450);text(labels[i][1],x+32,555,25,i===2?C.sage:C.stone);ctx.globalAlpha=1;});arrow(587,560,645,560);arrow(1144,560,1203,560);
 text('Standalone / headless runner',662,765,25,C.ink,500);line(1083,779,1130,779,C.olive,2);line(1130,779,1130,630,C.olive,2);arrow(1130,630,1207,630,C.olive,2);line(1454,665,1454,722,C.olive,2);
 ['Browser','Models','Storage'].forEach((s,i)=>{rect(1206+i*180,740,166,78,C.sage,8);text(s,1224+i*180,766,23,C.olive,500);});text('ADAPTERS',1219,694,17,C.stone,500);
 const travel=(t*.2)%1;dot(lerp(588,1200,travel),560,5,C.olive);
}
function ordering(u,t){introText(6,u,true);const ys=[505,621,737];text('INDEPENDENT REQUESTS',104,416,18,C.stone,500);text('VALIDATED DECISIONS',1000,416,18,C.stone,500);text('APPLY IN LOGICAL ORDER',1435,416,18,C.olive,500);
 ys.forEach((y,i)=>{iconPerson(130,y-8,colors[i],.8);text(['Persona A','Persona B','Persona C'][i],180,y-12,27,C.ink,450);line(385,y+10,930,y+10,C.line,4);const end=[.58,.28,.42][i];const p=clamp((u-.06)/end);line(385,y+10,lerp(385,930,p),y+10,colors[i],4);dot(lerp(385,930,p),y+10,8,colors[i]);if(p===1){rect(997,y-26,305,74,'#ffffff',8,C.line);text(['Decision A','Decision B','Decision C'][i],1023,y-3,25,colors[i],500);}
 const committed=u>.68+i*.07;rect(1435,y-26,330,74,committed?C.olive:C.sage,8);text(`${i+1}    ${['Apply A','Apply B','Apply C'][i]}`,1464,y-3,25,committed?C.paper:C.stone,450);if(committed)arrow(1318,y+10,1420,y+10,C.olive);});
 text('Finish order can differ',440,842,24,C.stone);text('Committed order stays stable',1350,842,24,C.olive,500);line(104,925,1816,925,C.line,2);text('Product → frozen snapshot → exposure → decisions → ordered updates → next round',260,935,23,C.stone);
}
function repeatability(u,t){introText(8,u,true);const data=[['Event replay','Saved events → state','No new model or browser calls'],['Recorded-input execution','Saved inputs → coordinator','Same outcomes despite delays'],['Fresh replicate','New model + environment calls','Variation remains possible']];
 data.forEach((d,i)=>{const x=104+i*570,e=ease(u*6-i*.22);ctx.save();ctx.globalAlpha=e;ctx.translate(0,(1-e)*25);rect(x,458,536,378,i===2?C.sage:'#ffffff',12,C.line);text('0'+(i+1),x+30,486,22,C.olive,500);if(i===0){for(let j=0;j<4;j++){rect(x+35+j*53,541,38,43,C.olive,5);if(j<3)line(x+75+j*53,563,x+86+j*53,563,C.olive,2);}}if(i===1){[0,1,2].forEach(j=>{line(x+37,551+j*22,x+197-j*23,551+j*22,colors[j],4);dot(x+210,571,9,C.olive);});}if(i===2){[0,1,2,3,4].forEach(j=>dot(x+48+j*44,569+Math.sin(j+t*.5)*19,12,colors[j]));}
 text(d[0],x+30,634,i===1?30:34,C.ink,450);text(d[1],x+30,699,25,C.ink);text(d[2],x+30,754,22,C.stone);ctx.restore();});pill('Design targets',104,872,186);text('Dedicated run storage and recovery are future work.',316,881,24,C.stone);
}
function evaluation(u,t){introText(10,u,true);const xs=[104,570,1036];xs.forEach((x,i)=>{const e=ease(u*6-i*.3);ctx.save();ctx.globalAlpha=e;rect(x,456,408,338,'#ffffff',12,C.line);text(`Independent pair ${i+1}`,x+26,482,26,C.ink,450);for(let w=0;w<2;w++){text(w?'B':'A',x+47+w*185,548,25,w?C.blue:C.olive,500);[0,1,2].forEach(j=>iconPerson(x+50+w*185+j*42,610,colors[j],.46));}line(x+200,558,x+200,668,C.line,2);text('Matched inputs',x+100,682,22,C.stone);text(`Δ${i+1} = outcome B − A`,x+52,731,24,C.olive,500);ctx.restore();});arrow(1461,622,1510,622);rect(1528,530,288,195,C.sage,12);text('Estimate',1556,559,29,C.ink,450);text('across pairs',1556,606,27,C.olive,450);text('with uncertainty',1556,655,22,C.stone);text('CONTROLS',104,858,18,C.stone,500);['Social on / off','Ranked / chronological','Alternative networks'].forEach((s,i)=>pill(s,104+i*520,903,460));}
function render(frame){const t=frame/24;let i=timing.findLastIndex(s=>t>=s.start);i=Math.max(0,i);const s=timing[i],local=t-s.start,d=s.end-s.start,u=clamp(local/d);ctx.globalAlpha=1;ctx.fillStyle=C.paper;ctx.fillRect(0,0,1920,1080);header();groups.forEach((g,j)=>{if(g)g.visible=j===i;});if(groups[i]){animate[i](u,t);splitScene(i,u,t);}else{({3:architecture,6:ordering,8:repeatability,10:evaluation})[i](u,t);}footer(i);
 // Brief paper dissolve at each chapter boundary; content stays on screen throughout.
 const wash=local<.28?(1-local/.28)*.95:(d-local<.20?(1-(d-local)/.20)*.6:0);if(wash>0){ctx.globalAlpha=wash;ctx.fillStyle=C.paper;ctx.fillRect(0,124,1920,840);ctx.globalAlpha=1;}
}
window.setFrame=render;window.duration=timing.at(-1).end;window.sceneTiming=timing;
window.exportModels=async()=>{groups.forEach((g,i)=>{if(g){g.visible=true;g.position.x=i*12;}});const data=await new GLTFExporter().parseAsync(world,{binary:true,onlyVisible:false});return Array.from(new Uint8Array(data));};
window.ready=true;render(60);
