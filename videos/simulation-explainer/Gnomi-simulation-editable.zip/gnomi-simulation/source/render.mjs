import {chromium} from 'playwright-core';
import {createServer} from 'node:http';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve,extname,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const mime={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.woff2':'font/woff2','.png':'image/png','.svg':'image/svg+xml','.json':'application/json'};
const server=createServer((req,res)=>{try{const p=resolve(root,'.'+decodeURIComponent(req.url.split('?')[0]));if(!p.startsWith(root+'/'))throw Error('outside root');res.setHeader('Content-Type',mime[extname(p)]||'application/octet-stream');res.end(readFileSync(p));}catch{res.statusCode=404;res.end('Not found');}});
await new Promise(r=>server.listen(8188,'127.0.0.1',r));
const browser=await chromium.launch({headless:true,...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE?{executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE}:{}),args:['--use-angle=metal','--disable-background-timer-throttling','--disable-renderer-backgrounding']});
const errors=[];
const makePage=async()=>{const p=await browser.newPage({viewport:{width:1920,height:1080},deviceScaleFactor:1});p.on('pageerror',e=>{errors.push(e.message);console.error(e.message);});await p.goto('http://127.0.0.1:8188/source/index.html');await p.waitForFunction(()=>window.ready,{timeout:60000});return p;};
const mode=process.argv[2]||'stills';
try{
 const timing=JSON.parse(readFileSync(root+'/source/timing.json'));
 if(mode==='stills'){
  const p=await makePage();for(let i=0;i<timing.length;i++){const s=timing[i],f=Math.round((s.start+(s.end-s.start)*.62)*24);await p.evaluate(f=>window.setFrame(f),f);await p.screenshot({path:`${root}/frames/scene-${String(i+1).padStart(2,'0')}.png`});console.log('still',i+1);}
  const bytes=await p.evaluate(()=>window.exportModels());writeFileSync(root+'/assets/simulation-models.glb',Buffer.from(bytes));
 }else{
  const N=Math.round(timing.at(-1).end*24),workers=3;
  const chosen=process.argv[3]===undefined?Array.from({length:workers},(_,i)=>i):[Number(process.argv[3])];
  await Promise.all(chosen.map(async i=>{
   const page=await makePage(),start=Math.floor(N*i/workers),end=Math.floor(N*(i+1)/workers);
   const ff=spawn('ffmpeg',['-y','-loglevel','error','-f','image2pipe','-framerate','24','-vcodec','mjpeg','-i','pipe:0','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p',`${root}/source/part-${i}.mp4`]);ff.stderr.on('data',d=>process.stderr.write(d));
   for(let f=start;f<end;f++){
    const jpg=await page.evaluate(f=>{window.setFrame(f);return document.querySelector('#film').toDataURL('image/jpeg',.96).split(',')[1];},f);
    if(!ff.stdin.write(Buffer.from(jpg,'base64')))await once(ff.stdin,'drain');
    if((f-start)%240===0)console.log(`worker ${i}: ${f-start}/${end-start}`);
   }
   ff.stdin.end();const [code]=await once(ff,'close');if(code!==0)throw Error('ffmpeg exit '+code);await page.close();console.log(`worker ${i} complete`);
  }));
  writeFileSync(root+'/source/concat.txt',Array.from({length:workers},(_,i)=>`file 'part-${i}.mp4'`).join('\n')+'\n');
 }
 if(errors.length)throw Error(errors.join('\n'));
}finally{await browser.close();server.close();}
